import java.util.ArrayList;
public class Gegner1 implements Gegner{
    private int speed, bulletFrequency, xValue, yValue, length;
    private ArrayList<Beobachter> beobachter;
    public Gegner1(int s, int b, int x, int y, int l) {
        speed=s;
        bulletFrequency=b;
        xValue=x;
        yValue=y;
        length=l;
        beobachter=new ArrayList<Beobachter>();
    }
    
    public void anmelden(Beobachter b){
       beobachter.add(b);
    }
    
    public void setSpeed(int s){
       speed=s;
    }
    
    public int getSpeed(){
        return speed;
    }
    
    public void setBulletFrequency(int b){
        bulletFrequency=b;
    }
    
    public int getBulletFrequency(){
        return bulletFrequency;
    }
    
    public int getXPosition(){
        return xValue;
    }
    
    public int getYPosition(){
        return yValue;
    }
    
    public void setPosition(int x, int y){
        xValue=x;
        yValue=y;
    }
    
    public void alleInformieren() {
		for(Beobachter b: beobachter){
            b.geändert();
        }
	}
}