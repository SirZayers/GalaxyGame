import java.awt.*;
import javax.swing.JLabel;
import java.io.File;
public class Ansicht extends javax.swing.JComponent implements Beobachter{
    private Spieler spieler;
    private Gegner1 gegner;
    public Ansicht(Spieler q, Gegner1 b){
        spieler=q;
        gegner=b;
        spieler.anmelden(this);
        gegner.anmelden(this);
        setFocusable(true);
    }

    public void paint(Graphics g){
        Toolkit zeugs=getToolkit();
        Image spieler=zeugs.getImage("spieler.png");
        g.drawImage(spieler, spieler.getX(), spieler.getY(), this);
    }

    public void geändert(){
        repaint();
    }

    public int getXSpieler(){
        return spieler.getX();
    }

    public int getYSpieler(){
        return spieler.getY();
    }

    
}