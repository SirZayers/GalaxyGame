public interface Beobachter{
    void geändert();
}